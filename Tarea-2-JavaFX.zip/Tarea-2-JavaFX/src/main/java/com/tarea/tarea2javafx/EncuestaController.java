package com.tarea.tarea2javafx;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;

public class EncuestaController {

    @FXML private RadioButton r1a, r1b, r1c, r1d;
    @FXML private RadioButton r2a, r2b, r2c, r2d;
    @FXML private RadioButton r3a, r3b, r3c, r3d;
    @FXML private RadioButton r4a, r4b, r4c, r4d;
    @FXML private Label lblError;

    private ToggleGroup grupo1, grupo2, grupo3, grupo4;

    @FXML
    public void initialize() {
        grupo1 = new ToggleGroup();
        r1a.setToggleGroup(grupo1);
        r1b.setToggleGroup(grupo1);
        r1c.setToggleGroup(grupo1);
        r1d.setToggleGroup(grupo1);

        grupo2 = new ToggleGroup();
        r2a.setToggleGroup(grupo2);
        r2b.setToggleGroup(grupo2);
        r2c.setToggleGroup(grupo2);
        r2d.setToggleGroup(grupo2);

        grupo3 = new ToggleGroup();
        r3a.setToggleGroup(grupo3);
        r3b.setToggleGroup(grupo3);
        r3c.setToggleGroup(grupo3);
        r3d.setToggleGroup(grupo3);

        grupo4 = new ToggleGroup();
        r4a.setToggleGroup(grupo4);
        r4b.setToggleGroup(grupo4);
        r4c.setToggleGroup(grupo4);
        r4d.setToggleGroup(grupo4);
    }

    @FXML
    private void calcular() {
        if (grupo1.getSelectedToggle() == null ||
                grupo2.getSelectedToggle() == null ||
                grupo3.getSelectedToggle() == null ||
                grupo4.getSelectedToggle() == null) {
            lblError.setText("Por favor responde todas las preguntas.");
            return;
        }

        int correctas = 0;
        if (grupo1.getSelectedToggle() == r1b) correctas++;
        if (grupo2.getSelectedToggle() == r2c) correctas++;
        if (grupo3.getSelectedToggle() == r3c) correctas++;
        if (grupo4.getSelectedToggle() == r4d) correctas++;

        int incorrectas = 4 - correctas;
        int puntaje = correctas * 5;

        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/com/tarea/tarea2javafx/Resultado.fxml"));
            Stage stage = new Stage();
            stage.setScene(new Scene(loader.load()));
            stage.setTitle("Resultado");

            ResultadoController ctrl = loader.getController();
            ctrl.setResultados(puntaje, correctas, incorrectas);

            stage.show();

            Stage actual = (Stage) lblError.getScene().getWindow();
            actual.close();

        } catch (Exception e) {
            lblError.setText("Error al cargar resultados.");
        }
    }
}
