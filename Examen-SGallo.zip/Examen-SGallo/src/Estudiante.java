import java.util.Objects;

public class Estudiante extends Persona{
    private int edad;
    public Estudiante(String nombre, String correo, int edad) {
        super(nombre, correo);
        setEdad(edad);
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        if (edad < 15 || edad > 35){
            throw new IllegalArgumentException("Error: Edad ingresda no valida.");
        }
        this.edad = edad;
    }

    @Override
    public boolean equals(Object std){
        if (this == std) return true;
        if (std == null || getClass() != std.getClass()) return false;
        Persona persona = (Estudiante) std;
        return Objects.equals(this.getCorreo(), ((Estudiante) std).getCorreo());
    }

    @Override
    public int hashCode(){
        return Objects.hash(getCorreo());
    }

    @Override
    public String obtenerRol() {
        return "Estudiante: " + getNombre();
    }

    @Override
    public String toString() {
        return "[ Edad: " + edad + super.toString();
    }
}
