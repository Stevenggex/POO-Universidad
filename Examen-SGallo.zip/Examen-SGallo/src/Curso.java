import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class Curso implements CrudEstudiante{
    private String nombreCurso;
    private Set<Estudiante> listaEstudiantes;
    private Map<String, Double> calificaciones;

    public Curso(String nombreCurso) {
        setNombreCurso(nombreCurso);
        this.listaEstudiantes = new HashSet<>();
        this.calificaciones = new HashMap<>();
    }

    public String getNombreCurso() {
        return nombreCurso;
    }

    public void setNombreCurso(String nombreCurso) {
        if (nombreCurso == null || nombreCurso.trim().isEmpty()){
            throw  new IllegalArgumentException("Error: Nombre del curso no ouede estar vacio.");
        }
        this.nombreCurso = nombreCurso;
    }

    public void buscarCorreo(String correo){
        for (Estudiante c : listaEstudiantes){
            if (c.getCorreo() == correo){
                System.out.println("Estudiante encontrado " + c.getNombre());
                return;
            } else {
                System.out.println("Estudiante no encontrado.");
            }
        }
    }

    @Override
    public void registrarEstudiante(String nombre, String correo, int edad) {
        boolean registrado = listaEstudiantes.isEmpty();

        if (!registrado){
            throw new IllegalArgumentException("Error: Ya existe un estudiante registrado con ese correo.");
        } else {
            System.out.println("Estudiante registrado con exito.");
        }
    }

    @Override
    public void registrarNota(String correo, double nota) {
        if (listaEstudiantes.isEmpty()){
            System.out.println("Error: No existen datos todavia.");
            return;
        }

        calificaciones.put(correo, nota);
        System.out.println("Nota registrada con exito.");

    }

    @Override
    public void actualizarNota(String correo, double nuevaNota) {
        if (calificaciones.isEmpty()){
            System.out.println("Error: No existen datos todavia.");
            return;
        }
        if (calificaciones.containsKey(correo)){
            calificaciones.put(correo, nuevaNota);
            System.out.println("Nota actualizada con exito.");
        } else {
            System.out.println("Error: Correo ingresado para actualizar nota no existe.");
        }

    }

    @Override
    public void eliminarNota(String correo) {
        if (calificaciones.isEmpty()){
            System.out.println("Error: No existen datos todavia.");
            return;
        }
        if (calificaciones.containsKey(correo)){
            calificaciones.remove(correo);
            System.out.println("Nota eliminada con exito.");
        } else {
            System.out.println("Error: Nota no se pudo borrar, porque correo inghresado no existe.");
        }

    }

    @Override
    public double promedioCurso() {
        return 0;
    }

    @Override
    public String mejorEstudiante() {
        return "";
    }


}
