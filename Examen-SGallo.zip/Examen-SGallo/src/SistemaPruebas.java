import java.util.Scanner;

public class SistemaPruebas {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        Curso curse = new Curso("GR1");
        int op = 0;
        int opc = 0;
        int opcn = 0;
        do {
            System.out.println("-- SISTEMA EDUPLUS --");
            System.out.println("1. Gestion Estudiantes");
            System.out.println("2. Gestion notas estudiantes");
            System.out.println("3. Salir");
            System.out.println("Seleccione una opcion: ");
            op = sc.nextInt();
            sc.nextLine();

            switch (op){
                case 1:
                    do {
                        System.out.println("\n=== GESTION ESTUDIANTES ===");
                        System.out.println("1. Registrar estudiante");
                        System.out.println("2. Buscar estudiantes registrados");
                        System.out.println("3. Salir");
                        System.out.println("Seleccione una opcion: ");
                        opc = sc.nextInt();
                        sc.nextLine();

                        switch (opc){
                            case 1:
                                System.out.println("\n== REGISTRAR ESTUDIANTE ==");

                                System.out.println("Nombre: ");
                                String nombre = sc.nextLine();

                                System.out.println("Correo: ");
                                String correo = sc.nextLine();

                                System.out.println("Edad: ");
                                int edad = sc.nextInt();
                                sc.nextLine();

                                curse.registrarEstudiante(nombre, correo, edad);
                                break;
                            case 2:
                                System.out.println("Correo: ");
                                String correo_buscar = sc.nextLine();

                                curse.buscarCorreo(correo_buscar);
                                break;
                            case 3:
                                System.out.println("Saliendo de gestion estudiantes...");
                                break;
                            default:
                                System.out.println("Error: Opcion invalida.");
                                break;
                        }
                    } while (opc != 3);
                    break;
                case 2:
                    do {
                        System.out.println("\n== GESTION DE NOTAS ESTUDIANTES ==");
                        System.out.println("1. Registrar nota");
                        System.out.println("2. Actualizar nota: ");
                        System.out.println("3. Eliminar nota");
                        System.out.println("4. Mostrar Promedio Curso");
                        System.out.println("5. Mostrar el correo del estudiante con la nota mas alta");
                        System.out.println("6. Salir");
                        System.out.println("Seleccione una opcion: ");
                        opcn = sc.nextInt();

                        switch (opcn){
                            case 1:
                                System.out.println("\n-- REGISTRAR NOTA --");

                                System.out.println("Correo: ");
                                String correo = sc.nextLine();
                                sc.nextLine();

                                System.out.println("Nota: ");
                                double nota = sc.nextDouble();

                                curse.registrarNota(correo, nota);
                                break;
                            case 2:
                                System.out.println("\n-- ACTUALIZAR NOTA --");

                                System.out.println("Correo: ");
                                String correo_actualizar = sc.nextLine();
                                sc.nextLine();

                                System.out.println("Nueva nota: ");
                                double nueva_nota = sc.nextDouble();

                                curse.actualizarNota(correo_actualizar, nueva_nota);
                                break;
                            case 3:
                                System.out.println("\n-- ELIMINAR NOTA --");

                                System.out.println("Correo: ");
                                String correo_eliminar = sc.nextLine();

                                curse.eliminarNota(correo_eliminar);
                                break;
                            case 4:
                                System.out.println("\n-- PROMEDIO CURSO --");
                                break;
                            case 5:
                                System.out.println("\n-- ESTUDIANTE CON LA NOTA MAS ALTA --");
                                break;
                            case 6:
                                System.out.println("Saliendo del sistema de gestion de notas...");
                                break;
                            default:
                                System.out.println("Error: Opcion invalida.");
                                break;
                        }

                    } while (opcn != 6);
                    break;
                case 3:
                    System.out.println("Saliendo del sistema EduPlus");
                    break;
                default:
                    System.out.println("Error: Opcion invalida.");
                    break;
            }
        } while (op != 3);
        return;
    }
}
