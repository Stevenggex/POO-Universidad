public interface CrudEstudiante {
    void registrarEstudiante(String nombre, String  correo, int edad);
    void registrarNota(String correo, double nota);
    void actualizarNota(String correo, double nuevaNota);
    void eliminarNota(String correo);
    double promedioCurso();
    String mejorEstudiante();
}
