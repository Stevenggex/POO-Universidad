public abstract class Persona {
    private String nombre;
    private String correo;

    public Persona(String nombre, String correo) {
        setNombre(nombre);
        setCorreo(correo);
    }

    public String getNombre() {
        return nombre;
    }

    public String getCorreo() {
        return correo;
    }

    public void setNombre(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()){
            throw new IllegalArgumentException("Error: Nombre no puede estar vacio.");
        }
        this.nombre = nombre;
    }

    public void setCorreo(String correo) {
        if (correo == null || correo.trim().isEmpty()){
            throw new IllegalArgumentException("Error: Correo no puede estar vacio.");
        }
        if (!correo.contains("@")){
            throw new IllegalArgumentException("Error: El correo debe tener el '@' obligatoriamente.");
        }
        this.correo = correo;
    }

    public abstract String obtenerRol();

    @Override
    public String toString(){
        return "- Nombre: " +  nombre + " - Correo: " + correo + " ]";
    }
}
