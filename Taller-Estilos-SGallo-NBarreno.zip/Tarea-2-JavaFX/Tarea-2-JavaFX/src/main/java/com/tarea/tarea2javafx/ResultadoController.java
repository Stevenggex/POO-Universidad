package com.tarea.tarea2javafx;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class ResultadoController {

    @FXML private Label lblPuntaje;
    @FXML private Label lblCorrectas;
    @FXML private Label lblIncorrectas;

    public void setResultados(int puntaje, int correctas, int incorrectas) {
        lblPuntaje.setText("Puntaje: " + puntaje + " / 20");
        lblCorrectas.setText("✅ Respuestas correctas: " + correctas);
        lblIncorrectas.setText("❌ Respuestas incorrectas: " + incorrectas);
    }

    @FXML
    private void cerrar() {
        Stage stage = (Stage) lblPuntaje.getScene().getWindow();
        stage.close();
    }
}