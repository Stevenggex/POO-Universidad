package com.tarea.tarea2javafx;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

public class LoginController {

    @FXML private TextField txtUsuario;
    @FXML private PasswordField txtContrasena;
    @FXML private ComboBox<String> cmbRol;
    @FXML private Label lblError;

    @FXML
    public void initialize() {
        cmbRol.setItems(FXCollections.observableArrayList("Administrador", "Cajero"));
        cmbRol.getSelectionModel().selectFirst();
    }

    @FXML
    private void ingresar() {
        String usuario = txtUsuario.getText().trim();
        String contrasena = txtContrasena.getText().trim();
        String rol = cmbRol.getValue();

        if (usuario.isEmpty() || contrasena.isEmpty()) {
            lblError.setText("Complete todos los campos.");
            return;
        }

        boolean credencialesValidas =
                (rol.equals("Administrador") && usuario.equals("admin") && contrasena.equals("1234")) ||
                        (rol.equals("Cajero") && usuario.equals("cajero") && contrasena.equals("1234"));

        if (!credencialesValidas) {
            lblError.setText("Usuario, contraseña o rol incorrectos.");
            return;
        }

        try {
            String fxml = rol.equals("Administrador")
                    ? "/com/tarea/tarea2javafx/Administrador.fxml"
                    : "/com/tarea/tarea2javafx/Cajero.fxml";

            //Navegacion
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxml));
            Stage nuevoStage = new Stage();
            nuevoStage.setScene(new Scene(loader.load()));
            nuevoStage.setTitle(rol);
            nuevoStage.show();

            //Cerrar la ventana
            Stage loginStage = (Stage) txtUsuario.getScene().getWindow();
            loginStage.close();

        } catch (Exception e) {
            lblError.setText("Error al cargar el formulario.");
        }
    }

    @FXML
    private void salir() {
        javafx.application.Platform.exit();
    }
}
