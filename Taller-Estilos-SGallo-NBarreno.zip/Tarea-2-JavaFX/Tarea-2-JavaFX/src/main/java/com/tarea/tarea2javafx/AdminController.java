package com.tarea.tarea2javafx;

import javafx.fxml.FXML;
import javafx.stage.Stage;

public class AdminController {

    @FXML
    private void cerrar() {
        Stage stage = new Stage();
        stage.close();
    }
}