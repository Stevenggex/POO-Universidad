package com.tarea.tarea2javafx;

import javafx.fxml.FXML;

public class CajeroController {

    @FXML
    private void cerrar() {
        javafx.application.Platform.exit();
    }
}