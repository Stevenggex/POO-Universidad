module com.tarea.tarea2javafx {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.tarea.tarea2javafx to javafx.fxml;
    exports com.tarea.tarea2javafx;
}